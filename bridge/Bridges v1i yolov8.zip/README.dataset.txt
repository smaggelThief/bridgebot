# Bridges > 2023-10-19 7:27pm
https://universe.roboflow.com/sergey-d5rx9/bridges-ilstt

Provided by a Roboflow user
License: CC BY 4.0

